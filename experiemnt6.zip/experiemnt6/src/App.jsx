import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Formc from './components/Form.jsx'
import SinglePageApp from './components/spa.jsx'

function App() {
  const [count, setCount] = useState(0)
  return (
    <>
     <SinglePageApp />
    </>
  )
}

export default App